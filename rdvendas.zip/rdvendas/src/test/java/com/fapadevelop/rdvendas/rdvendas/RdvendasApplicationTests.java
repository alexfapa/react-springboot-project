package com.fapadevelop.rdvendas.rdvendas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RdvendasApplicationTests {

	@Test
	void contextLoads() {
	}

}
